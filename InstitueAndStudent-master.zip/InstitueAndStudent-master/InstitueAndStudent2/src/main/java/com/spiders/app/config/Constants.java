package com.spiders.app.config;

public class Constants {
	
	public final static String ADMIN_ROLE = "ADMIN";
	public final static String USER_ROLE = "USER";


}
